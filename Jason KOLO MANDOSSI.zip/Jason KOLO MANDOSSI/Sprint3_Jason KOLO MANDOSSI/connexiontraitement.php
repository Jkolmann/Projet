<?php 
session_start();
include('connexion.php');
//Vérification si l'utilisateur s'est bien enregistré

if (isset($_POST["email"]) && isset($_POST["password"])){	

    //Création des variables si elles existent

    $email=htmlspecialchars($_POST["email"]);
    $password=htmlspecialchars($_POST["password"]);
	
	//Création de la requête préparée

    $check = $connexion->prepare("SELECT * FROM utilisateurs  WHERE email = ?");
	$check->execute(array($email));//Mettre la valeur de l'email tapé dans le formulaire de connexion dans la variable email dans la requête préparée
	$utilisateurs = $check->fetch();
	$Existe = $check->rowCount(); //Voir si l'email existe dans la base de donnée si oui il sera = à 1

	if($Existe == 1){//si l'email existe alors
		$password = hash('sha256', $password);//crypté le mot de passe tapé dans le formulaire de connexion
		if($utilisateurs['password'] === $password){//si le mot de passe crypté dans le formulaire de connexion est égal au mot de passe crypté dans la base de donnée alors créer une session et renvoyer à la page de réservation
			$_SESSION['user'] = $utilisateurs['email'];///création d'une session pour l'utilisateur avec l'email
			header('location: reservation.php');
		}
		else{//si les mots de passes ne correspondent pas
			echo "<script type=\"text/javascript\">";
                echo "alert('Mot de passe incorrect');";
                echo "window.history.back();";
                echo "</script>";
		}
	}else{//si l'email n'existe pas dans la base de donnée
		echo "<script type=\"text/javascript\">";
                echo "alert('Comptes introuvables');";
                echo "window.history.back();";
                echo "</script>";
	}
                                    
	  
}















?>