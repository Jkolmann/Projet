<?php 

include("connexion.php");

//

if(isset($_GET['supprimer'])) {
		
    $id = $_GET['supprimer'];
    
    $requete = $connexion->query("DELETE FROM reservation WHERE id=$id");


    header('location:reservation.php');
    
}

















?>